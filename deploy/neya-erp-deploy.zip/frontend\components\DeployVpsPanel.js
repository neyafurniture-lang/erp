'use client';

import { useEffect, useState } from 'react';
import { api, getApiRoot, getApiUrl, getToken } from '../lib/api';

function formatBytes(n) {
  if (!n) return '—';
  if (n < 1024) return `${n} o`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} Ko`;
  return `${(n / (1024 * 1024)).toFixed(1)} Mo`;
}

export default function DeployVpsPanel() {
  const [local, setLocal] = useState(null);
  const [remoteUrl, setRemoteUrl] = useState('https://erp.neyafurniture.ca');
  const [remote, setRemote] = useState(null);
  const [preparing, setPreparing] = useState(false);
  const [probing, setProbing] = useState(false);
  const [result, setResult] = useState(null);
  const [exports, setExports] = useState([]);
  const [err, setErr] = useState('');
  const [vpsHost, setVpsHost] = useState('51.222.31.75');
  const [includeDb, setIncludeDb] = useState(true);

  async function load() {
    setErr('');
    try {
      const data = await api('/deploy/diagnostics');
      setLocal(data.local);
      if (data.remote) setRemote(data.remote);
      const list = await api('/deploy/exports');
      setExports(list);
    } catch (e) {
      setErr(e.message);
    }
  }

  useEffect(() => { load(); }, []);

  async function probeVps() {
    setProbing(true);
    setErr('');
    try {
      const data = await api(`/deploy/diagnostics?remote=${encodeURIComponent(remoteUrl)}`);
      setRemote(data.remote);
    } catch (e) {
      setErr(e.message);
    } finally {
      setProbing(false);
    }
  }

  async function generatePackage() {
    setPreparing(true);
    setErr('');
    setResult(null);
    try {
      const data = await api('/deploy/prepare', {
        method: 'POST',
        body: JSON.stringify({ includeDb, vpsHost, vpsPath: '/opt/neya-erp' }),
      });
      setResult(data);
      await load();
    } catch (e) {
      setErr(e.message);
    } finally {
      setPreparing(false);
    }
  }

  async function downloadFile(filename) {
    const token = getToken();
    const res = await fetch(`${getApiUrl()}/deploy/download/${encodeURIComponent(filename)}`, {
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || `Téléchargement échoué (${res.status})`);
    }
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  }

  const mailIssue = remote?.ok && !remote?.mailOk;

  return (
    <div className="space-y-6">
      <section className="card">
        <h2 className="font-heading text-lg mb-2">Diagnostic déploiement</h2>
        <p className="text-sm text-neya-muted mb-4">
          Compare votre environnement local avec le VPS. Les erreurs <strong>404 sur Courriel</strong> viennent
          presque toujours d&apos;un backend VPS qui n&apos;a pas les routes <code className="text-xs">gmail/threads</code>.
        </p>

        {err && (
          <div className="text-sm text-red-700 bg-red-50 px-3 py-2 rounded-lg mb-4">{err}</div>
        )}

        {mailIssue && (
          <div className="text-sm text-amber-900 bg-amber-50 border border-amber-200 px-4 py-3 rounded-lg mb-4">
            <p className="font-medium mb-1">Cause probable des 404 mail</p>
            <p>Le VPS n&apos;a pas la fonctionnalité « Fils courriel + synthèse IA ». Générez un package ci-dessous puis redéployez.</p>
          </div>
        )}

        <div className="grid md:grid-cols-2 gap-4 mb-4">
          <div className="rounded-xl border border-neya-border p-4 bg-neya-surface/40">
            <p className="text-xs font-semibold uppercase tracking-wide text-neya-muted mb-2">Local (cette machine)</p>
            {local ? (
              <ul className="text-sm space-y-1">
                <li>Version <span className="font-mono">{local.version}</span> · commit <span className="font-mono">{local.commit}</span></li>
                <li>Tables mail : {local.tables?.email_threads ? '✓' : '✗'} email_threads</li>
                <li>Prêt : {local.ready ? '✓ oui' : '✗ migrations manquantes'}</li>
              </ul>
            ) : (
              <p className="text-sm text-neya-muted">Chargement…</p>
            )}
          </div>

          <div className="rounded-xl border border-neya-border p-4 bg-neya-surface/40">
            <p className="text-xs font-semibold uppercase tracking-wide text-neya-muted mb-2">VPS distant</p>
            <div className="flex gap-2 mb-2">
              <input
                className="input text-sm flex-1"
                value={remoteUrl}
                onChange={e => setRemoteUrl(e.target.value)}
                placeholder="https://erp.neyafurniture.ca"
              />
              <button type="button" onClick={probeVps} disabled={probing} className="btn-secondary text-xs shrink-0">
                {probing ? '…' : 'Vérifier'}
              </button>
            </div>
            {remote?.ok ? (
              <ul className="text-sm space-y-1">
                <li>Version <span className="font-mono">{remote.version || '?'}</span> · commit <span className="font-mono">{remote.commit || '?'}</span></li>
                <li>Courriel ERP : {remote.mailOk ? '✓' : '✗ manquant'}</li>
                {remote.missing?.length > 0 && (
                  <li className="text-amber-800 text-xs mt-2">
                    Manquant : {remote.missing.map(m => m.label).join(', ')}
                  </li>
                )}
              </ul>
            ) : remote ? (
              <p className="text-sm text-red-700">{remote.error || 'VPS inaccessible'}</p>
            ) : (
              <p className="text-sm text-neya-muted">Cliquez Vérifier pour comparer</p>
            )}
          </div>
        </div>
      </section>

      <section className="card">
        <h2 className="font-heading text-lg mb-2">Générer le package VPS</h2>
        <p className="text-sm text-neya-muted mb-4">
          Quand tout fonctionne en local, générez l&apos;archive et les instructions à copier sur le serveur.
        </p>

        <div className="grid sm:grid-cols-2 gap-4 mb-4">
          <label className="text-sm">
            <span className="label">IP / hôte VPS</span>
            <input className="input mt-1" value={vpsHost} onChange={e => setVpsHost(e.target.value)} placeholder="51.222.31.75" />
          </label>
          <label className="flex items-end gap-2 text-sm cursor-pointer pb-2">
            <input type="checkbox" checked={includeDb} onChange={e => setIncludeDb(e.target.checked)} className="accent-neya-orange" />
            Inclure export SQL (clients, projets, tâches…)
          </label>
        </div>

        <button type="button" onClick={generatePackage} disabled={preparing} className="btn-primary">
          {preparing ? 'Génération…' : 'Générer package + instructions VPS'}
        </button>

        {result && (
          <div className="mt-6 space-y-4">
            <div className="rounded-xl border border-green-200 bg-green-50/80 p-4 text-sm">
              <p className="font-medium text-green-900 mb-2">Package prêt</p>
              <ul className="space-y-2">
                <li>
                  <button type="button" onClick={() => downloadFile(result.files.zip)} className="text-neya-orange underline font-medium">
                    Télécharger {result.files.zip}
                  </button>
                  {' '}({formatBytes(result.manifest?.files?.zipSizeBytes)})
                </li>
                {result.files.sql && (
                  <li>
                    <button type="button" onClick={() => downloadFile(result.files.sql)} className="text-neya-orange underline">
                      Télécharger {result.files.sql}
                    </button>
                  </li>
                )}
                <li>
                  <button type="button" onClick={() => downloadFile(result.files.script)} className="text-neya-orange underline">
                    Script shell VPS
                  </button>
                </li>
                <li>
                  <button type="button" onClick={() => downloadFile(result.files.manifest)} className="text-neya-orange underline">
                    Manifeste JSON
                  </button>
                </li>
              </ul>
            </div>

            <div>
              <p className="text-xs font-semibold uppercase tracking-wide text-neya-muted mb-2">Commandes sur le VPS</p>
              <pre className="text-xs bg-neya-ink text-neya-cream p-4 rounded-xl overflow-x-auto whitespace-pre-wrap font-mono">
                {result.manifest?.instructions?.steps?.join('\n')}
                {'\n\n'}
                {result.manifest?.instructions?.oneLiner}
              </pre>
            </div>
          </div>
        )}
      </section>

      {exports.length > 0 && (
        <section className="card">
          <h2 className="font-heading text-lg mb-3">Exports récents</h2>
          <ul className="text-sm divide-y divide-neya-border">
            {exports.slice(0, 8).map(f => (
              <li key={f.name} className="py-2 flex justify-between gap-2">
                <button type="button" onClick={() => downloadFile(f.name)} className="text-neya-orange hover:underline truncate text-left">
                  {f.name}
                </button>
                <span className="text-neya-muted shrink-0">{formatBytes(f.size)}</span>
              </li>
            ))}
          </ul>
        </section>
      )}

      <section className="card bg-red-50/50 border border-red-200/60">
        <h2 className="font-heading text-base mb-2 text-red-900">Rollback d&apos;urgence</h2>
        <p className="text-sm text-red-900/80 mb-3">
          Si le site plante après un déploiement, restaure le backup DB + le commit précédent.
        </p>
        <pre className="text-xs font-mono bg-white border border-red-200/50 rounded-lg p-3 overflow-x-auto">
{`# Une fois sur le VPS :
cd /opt/neya-erp && sudo ./deploy/install-rollback.sh

# Depuis Windows :
.\\deploy\\vps-back.ps1

# Ou SSH direct :
ssh ubuntu@${vpsHost || '51.222.31.75'} back.sh`}
        </pre>
      </section>

      <section className="card bg-neya-cream/40">
        <h2 className="font-heading text-base mb-2">Raccourcis PowerShell (PC)</h2>
        <pre className="text-xs font-mono bg-white border border-neya-border rounded-lg p-3 overflow-x-auto">
{`cd ${typeof window !== 'undefined' ? '' : ''}..\\neya_erp_mvp
.\\deploy\\pack-for-vps.ps1
.\\deploy\\vps-migrate-local.ps1`}
        </pre>
        <p className="text-xs text-neya-muted mt-2">API locale : {getApiRoot()}</p>
      </section>
    </div>
  );
}
